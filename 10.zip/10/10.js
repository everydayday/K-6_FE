document.addEventListener("DOMContentLoaded",()=>{
  const btn = document.querySelector("#btn");
  
  btn.addEventListener("click",()=>{
    console.log("here");
    let numbers = [];
    while(numbers.length < 7){

      let n = Math.floor(Math.random()*45+1);
      if(numbers.includes(n)) continue;
      else numbers.push(n);
    }
    console.log(numbers);

    let spans = document.querySelectorAll("span");
    console.log(spans[0].innerHTML);

    spans.innerHTML = numbers.map((v,i)=>v[i]);
    // for(let i in zip(spans,numbers)){
      
    //   spans[i].innerHTML = numbers[i];
    // }

    
    console.log(spans);



  });

  



});